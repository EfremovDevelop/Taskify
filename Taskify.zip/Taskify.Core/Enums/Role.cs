﻿namespace Taskify.Core.Enums;

public enum Role
{
    Admin = 1,
    User = 2
}
