﻿namespace Taskify.DataAccess.Entities;

public class RolePermissionEntity
{
    public int RoleId { get; set; }

    public int PermissionId { get; set; }
}
