﻿namespace Taskify.Infrastructure;

public class CustomClaims
{
    public const string UserId = "userId";

    public const string UserName = "userName";
}
