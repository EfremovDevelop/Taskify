﻿namespace Taskify.API.Contracts.Projects;

public record ProjectsRequest(
    string Name,
    string Description);
